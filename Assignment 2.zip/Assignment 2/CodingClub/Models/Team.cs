using System.ComponentModel.DataAnnotations;

namespace CodingClub.Models
{
    public class Team
    {
        [Required]
        [Display(Name = "Team ID")]
        public int TeamId { get; set; }
        [Required]
        [Display(Name = "Team Name")]
        public string TeamName { get; set; }
        [Display(Name = "Team E-mail")]
        public string TeamEmail { get; set; }
        public Project Project {get; set;}
        public Student Student {get; set;}
    }
}