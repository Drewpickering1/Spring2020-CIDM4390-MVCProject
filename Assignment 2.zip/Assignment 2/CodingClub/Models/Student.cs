using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CodingClub.Models
{
    public class Student
    {
        [Required]
        [Display(Name = "Student ID")]
        public int StudentId { get; set; }
        [Required]
        [Display(Name = "Student First Name")]
        public string StudentFirstName { get; set; }
        [Required]
        [Display(Name = "Student Last Name")]
        public string StudentLastName { get; set; }
        [Required]
        [Display(Name = "Student E-Mail")]
        public string StudentEmail {get; set;}
        [Required]
        [Display(Name = "Student Phone Number")]
        public long StudentPhone {get; set;}
        public ICollection<Team> Teams { get; set; }

    }
}