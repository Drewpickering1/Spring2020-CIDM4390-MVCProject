using System;
using System.ComponentModel.DataAnnotations;

namespace CodingClub.Models
{
    public class Project
    {
        [Required]
        [Display(Name = "Project ID")]
        public int ProjectId { get; set; }
        [Required]
        [Display(Name = "Project Name")]
        public string ProjectName { get; set; }
        
        [Display(Name = "Project Description")]
        public string ProjectDescription { get; set; }
        public Client Client {get; set;}

    }
}