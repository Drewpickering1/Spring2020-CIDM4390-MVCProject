using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CodingClub.Models
{
    public class Client
    {
        [Required]
        [Display(Name = "Client ID")]
        public int ClientId { get; set; }
        [Required]
        [Display(Name = "Client First Name")]
        public string ClientFirstName { get; set; }
        [Required]
        [Display(Name = "Client Last Name")]
        public string ClientLastName { get; set; }
        [Required]
        [Display(Name = "Client E-Mail")]
        public string ClientEmail {get; set;}
        [Required]
        [Display(Name = "Client Phone Number")]
        public long ClientPhone {get; set;}

    }
}