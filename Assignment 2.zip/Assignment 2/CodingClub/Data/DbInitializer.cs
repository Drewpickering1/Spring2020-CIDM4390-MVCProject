using CodingClub.Data;
using CodingClub.Models;
using System;
using System.Linq;

namespace CodingClub.Data
{
    public static class DbInitializer
    {
        public static void Initialize(CodingClubContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Student.Any())
            {
                return;   // DB has been seeded
            }

            var students = new Student[]
            {
                new Student{StudentFirstName="Sally",StudentLastName="Sue",StudentEmail= "SallySue@hotmail.com", StudentPhone = 8069874516},
                new Student{StudentFirstName="Molly",StudentLastName="Ringwald",StudentEmail= "MollyRingwald@gmail.com", StudentPhone = 8915498632},
                new Student{StudentFirstName="Jack",StudentLastName="Sparrow",StudentEmail= "JackSparrow@outlook.com", StudentPhone = 2158645791},
                new Student{StudentFirstName="Mickey",StudentLastName="Mouse",StudentEmail= "MickeyMouse@yahoo.com", StudentPhone = 6455323223},
                new Student{StudentFirstName="Tom",StudentLastName="Segura",StudentEmail= "TomSegura@gmial.com", StudentPhone = 7215897674}
            };
            foreach (Student s in students)
            {
                context.Student.Add(s);
            }
            context.SaveChanges();

            var teams = new Team[]
            {
                new Team{TeamName="Diamond",TeamEmail="DiamondTeam@gmail.com"},
                new Team{TeamName="Gold",TeamEmail="GoldTeam@gmail.com"}

            };
            foreach (Team c in teams)
            {
                context.Team.Add(c);
            }
            context.SaveChanges();

            var projects = new Project[]
            {
                new Project{ProjectName="Get'er Done",ProjectDescription="Go into a farming facility, and create a system that can keep track of the amount of product made and create new ordering system."},
                new Project{ProjectName="Alrighty Then",ProjectDescription="Go into a veterinary facility, and create a system that can keep track of the number of animals coming in and create new database system."}
            };
            foreach (Project e in projects)
            {
                context.Project.Add(e);
            }
            context.SaveChanges();

             var clients = new Client[]
            {
                new Client{ClientFirstName="Larry",ClientLastName="TheCableGuy",ClientEmail="LarryTheCableGuy@outlook.com",ClientPhone= 7884546898},
                new Client{ClientFirstName="Jim",ClientLastName="Carrey",ClientEmail="JimCarrey@hotmail.com",ClientPhone= 9869748564}
                
            };
            foreach (Client y in clients)
            {
                context.Client.Add(y);
            }
            context.SaveChanges();
        }
    }
}