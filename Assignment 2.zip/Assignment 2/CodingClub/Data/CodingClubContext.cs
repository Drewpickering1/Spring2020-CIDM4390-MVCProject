using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CodingClub.Models;

namespace CodingClub.Data
{
    public class CodingClubContext : DbContext
    {
        public CodingClubContext (DbContextOptions<CodingClubContext> options)
            : base(options)
        {
        }

        public DbSet<CodingClub.Models.Student> Student { get; set; }
        public DbSet<CodingClub.Models.Team> Team { get; set; }
        public DbSet<CodingClub.Models.Project> Project { get; set; }
        public DbSet<CodingClub.Models.Client> Client { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().ToTable("Student");
            modelBuilder.Entity<Team>().ToTable("Team");
            modelBuilder.Entity<Project>().ToTable("Project");
            modelBuilder.Entity<Client>().ToTable("Client");
        } 
    }
}
